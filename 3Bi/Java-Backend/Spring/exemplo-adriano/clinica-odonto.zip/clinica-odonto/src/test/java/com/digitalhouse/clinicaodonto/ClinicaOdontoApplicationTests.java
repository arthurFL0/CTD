package com.digitalhouse.clinicaodonto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
